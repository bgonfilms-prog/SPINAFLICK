const CACHE = 'movie-wheel-v1';
const ASSETS = ['./','./index.html','./styles.css','./app.js','./firebase-config.js','./manifest.webmanifest','./icon.svg'];
self.addEventListener('install', (event) => event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(ASSETS))));
self.addEventListener('fetch', (event) => event.respondWith(caches.match(event.request).then((cached) => cached || fetch(event.request))));
